#!/system/bin/sh
setenforce 0
SCRIPT_PATH="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
chcon u:object_r:system_file:s0 "$SCRIPT_PATH"
chattr -i /data/system/mcd/df
chattr -i /cache/dcs_mode
am force-stop com.xiaomi.joyose
am force-stop com.xiaomi.powerchecker
killall -9 com.xiaomi.powerchecker 2>/dev/null
killall -9 com.xiaomi.joyose 2>/dev/null
pm clear com.xiaomi.joyose
pm clear com.xiaomi.powerchecker
pm enable com.miui.powerkeeper/.feedbackcontrol.abnormallog.ThermalLogService
pm enable com.miui.powerkeeper/.feedbackcontrol.FeedbackControlService
pm enable com.xiaomi.joyose
am start -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
pm enable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver
pm enable com.miui.powerkeeper/.thermal.ThermalService
pm enable com.miui.powerkeeper/.cloudcontrol.CloudUpdateJobService
pm enable com.miui.powerkeeper
am force-stop com.xiaomi.joyose
rm -f /data/cache/miui-thermal/*
rm -f /data/jinsen/
rm -f /data/system/mcd/df
rm -f /cache/dcs_mode
mkdir -p /vendor/etc/thermal/config
cp /vendor/etc/thermal*.conf /data/vendor/thermal/config/
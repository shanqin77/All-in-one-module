#!/system/bin/sh
MODDIR=${0%/*}

# 权限设置函数
set_perm() {
    chown $2:$3 $1
    chmod $4 $1
    chcon $5 $1
}

set_perm_recursive() {
    find $1 -type d 2>/dev/null | while read dir; do
        set_perm $dir $2 $3 $4 $6
    done
    find $1 -type f -o -type l 2>/dev/null | while read file; do
        set_perm $file $2 $3 $5 $6
    done
}

set_permissions() {
    set_perm_recursive $MODDIR 0 0 0755 0644 u:object_r:system_file:s0
}

# 配置文件操作
file="/data/jinsen/config.conf"
config="# 配置需重启生效\n#调度模式 OPERATION_MODE：官方=ON 第三方=OFF"

echo "*******************************"
echo "刷入中"
echo "你下一个云控何必是云控"
echo "刷入成功后请重启手机"
echo "*******************************"
rm -f /cache/miui-thermal/*
pm clear com.xiaomi.powerchecker
pm clear com.xiaomi.joyose
mkdir -p /data/jinsen/
[ -f /data/system/mcd/df ] && {
  chattr -i /data/system/mcd/df
  rm -f /data/system/mcd/df
}
echo '' > /data/system/mcd/df
chattr +i /data/system/mcd/df

# 音量键监听核心函数
volume_listener() {
  local timeout=0
  while :; do
    case $(getevent -qlc 1 | awk '/KEY_VOLUME/ {print $3}') in
      "KEY_VOLUMEUP") return 0 ;;
      "KEY_VOLUMEDOWN") return 1 ;;
    esac
    sleep 0.1
    timeout=$((timeout + 1))
    [ $timeout -gt 50 ] && return 2  # 5秒超时
  done
}

# 配置选择流程
echo "========================"
echo "选择调度方案："
echo "  音量上键 - 第三方调度"
echo "  音量下键 - 官方调度"
volume_listener
case $? in
  0) operation_mode="OFF" ;;
  1) operation_mode="ON" ;;
  *) operation_mode="ON" ;;  # 超时默认官方
esac

# 写入最终配置
echo -e "${config}\nOPERATION_MODE=${operation_mode}" > $file
chmod 600 $file

# 清理和权限设置
set_permissions
echo "================================"
echo "配置已写入：$file"
echo "修改配置后需重启手机生效！"
echo "================================"
#!/system/bin/sh
CONFIG_PATH="/data/jinsen/config.conf"

# 等待系统启动完成
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

main() {
    pm disable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver
    stop mi_thermald
    pm disable com.miui.daemon
}

# 模式选择
select_mode() {
    case $(grep -E '^OPERATION_MODE=' "$CONFIG_PATH" | cut -d= -f2) in
        "OFF"|"NO") unofficial_mode ;;
        *) official_mode ;;
    esac
}

official_mode() {
    pm enable com.xiaomi.joyose
    am start -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
    pm enable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver
    pm enable com.miui.powerkeeper/.thermal.ThermalService
    pm enable com.miui.powerkeeper/.cloudcontrol.CloudUpdateJobService
}

unofficial_mode() {
    stop miuibooster
    pm disable com.miui.powerkeeper/.cloudcontrol.CloudUpdateReceiver
    pm disable com.xiaomi.joyose
    pm disable com.miui.powerkeeper/.cloudcontrol.CloudUpdateJobService
    pm disable com.miui.powerkeeper/.thermal.ThermalService
}

mtk_dcs() {
    # 联发科专用处理
    if echo $(getprop ro.board.platform) | grep -q '^mt'; then
        no_dcs=/sys/kernel/ged/hal/dcs_mode
        umount $no_dcs 2>/dev/null
        echo 0 > $no_dcs
        
        if [ ! -f /cache/dcs_mode ]; then
            chmod 444 $no_dcs
            echo 0 > /cache/dcs_mode
            chattr +i /cache/dcs_mode 2>/dev/null
        fi
        
        mount --rbind /cache/dcs_mode $no_dcs 2>/dev/null
    else
        echo "骁龙平台跳过DCS优化" > /dev/null
    fi
}

select_mode
main
mtk_dcs
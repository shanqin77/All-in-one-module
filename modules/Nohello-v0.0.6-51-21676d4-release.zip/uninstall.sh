
rm -rf /data/adb/post-fs-data.d/.nohello_cleanup.sh
rm -rf /data/adb/nohello
